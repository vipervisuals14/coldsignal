# ColdSignal — Deploy to Cloudflare (new project)

This is a clean package of the fixed ColdSignal 4K music visualizer. Upload these files to a **new** Cloudflare Pages project so your old deployment stays untouched.

## What's fixed

- **4K preview** — defaults to 1080p (was 720p)
- **High-detail mesh** — lines up to 2000, mesh detail up to 4096
- **New effect sliders** — displacement depth, surface smoothness, color posterize
- **Music-video defaults** — boosted glow, chromatic aberration, grain, scanlines, bass response
- **TouchDesigner/Rutt-Etra style** — temporal feedback, color drift, slit scan, dither, glitch bands
- **SPA routing fixed** — `_routes.json` added so page refreshes don't 404

## Deploy to Cloudflare Pages (recommended)

1. Go to [dash.cloudflare.com](https://dash.cloudflare.com) → **Workers & Pages**
2. Click **Create application** → **Pages**
3. **Upload assets** → drag and drop `coldsignal-package.zip`, OR **Connect to Git** → select your repo
4. **Build settings:**
   - Build command: `npm run build`
   - Build output directory: `dist`
   - Root directory: `/` (the folder containing this package)
5. Click **Save and Deploy**

## Deploy via Wrangler (Workers)

1. Install: `npm install -g wrangler`
2. Log in: `wrangler login`
3. In this folder: `npm ci && npm run build`
4. Deploy: `wrangler deploy --name <your-project-name>`

## Important Cloudflare Pages settings

| Setting | Value |
|---------|-------|
| Build command | `npm run build` |
| Output directory | `dist` |
| Root directory | `/` |

If your build fails on Cloudflare, double-check these two settings in the Pages dashboard.

## Keeping your old deployment

This package is separate from your existing `nameless-haze-52fe` worker. Deploy it as a brand new Cloudflare Pages project with a different name.

## Files

| File | Purpose |
|------|---------|
| `index.html` | App entry point |
| `src/main.js` | UI, audio, export logic |
| `src/renderer.js` | WebGL 4K rendering engine |
| `src/audio.js` | Music analysis |
| `src/exporter.js` | 4K MP4/WebM video export |
| `src/keyframes.js`, `src/keyframe-editor.js` | Animation keyframes |
| `src/analysis.worker.js` | Audio analysis worker |
| `src/style.css` | UI styling |
| `public/_routes.json` | SPA routing (copied to dist by Vite) |
| `package.json` | Dependencies |
| `vite.config.js` | Build config |
| `wrangler.toml` | Cloudflare deploy config |
